package Programm;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Task1 {
    public static int maxDeepth;
    public static Pattern pt;
    public static String Out;

    public static String Task1(String path, String mask)
    {
        Out = "";
        maxDeepth = 0;
        File file = new File(path);
        Task_rec1(file, 0);

        System.out.println(maxDeepth);

        char[] ch = mask.toCharArray();
        String mask_ = "";

        for(int i = 0; i < ch.length;i++)
        {
            if(ch[i] == '?')
            {
                mask_+="[^ ]";
                continue;
            }
            if(ch[i] == '*')
            {
                mask_+="[^ ]*";
                continue;
            }

            mask_+="[";
            mask_+= ch[i];
            mask_+= "]";
        }
        System.out.println(mask_);

        pt = Pattern.compile(mask_);

        Task_rec2(file, 0);
        return Out;
    }

    public static void Task_rec1(File file, int depth)
    {
        File[] files = file.listFiles();

        if(files == null)
        {
            if(depth>=maxDeepth)
                maxDeepth = depth;
            return;
        }
        for(int i = 0; i < files.length;i++)
        {
            Task_rec1(files[i], depth+1);
        }
    }

    public static void Task_rec2(File file, int depth)
    {
        File[] files = file.listFiles();

        Matcher m = pt.matcher(file.getName());

        if(depth == maxDeepth && m.matches())
        {
            Out+= file.getName()+"\n";
            System.out.println(file.getName());
        }

        if(files == null)
        {
            return;
        }

        for(int i = 0; i < files.length;i++)
        {
            Task_rec2(files[i], depth+1);
        }
    }
}
