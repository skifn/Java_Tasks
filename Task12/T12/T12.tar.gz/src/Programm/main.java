package Programm;

public class main {
    public static void main(String[] args) {
        Forms form = new Forms();
    } //15 2
}
